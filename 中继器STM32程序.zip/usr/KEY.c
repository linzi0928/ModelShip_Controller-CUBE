#include "stm32f10x.h"
#include "stdio.h"
static void KEY_GPIO_Init(void)
{
GPIO_InitTypeDef GPIO_KEY_InitStructure;
  GPIO_KEY_InitStructure.GPIO_Pin = GPIO_Pin_10; 
	GPIO_KEY_InitStructure.GPIO_Speed = GPIO_Speed_10MHz; 
	GPIO_KEY_InitStructure.GPIO_Mode = GPIO_Mode_IPD; 
	GPIO_Init(GPIOA, &GPIO_KEY_InitStructure);
}
