#include "sys_config.h"
#include "stm32f10x.h"
#include "Usart.h"
#include "timer.h"
#include "stm32f10x_iwdg.h"
#include "wdg.h"
#include "sx12xxEiger.h"
#include "math.h"
void All_Init_Gen(void);
void GPIO_Init_Gen(void);
u16 led0pwmval=0,servo=0,tt,servox,servoy,tservo=0;
extern u16 fso;
extern u8 px[32];
uint8_t MY_TEST_Msg[21] = "ZDB_###_SX1278_TEST";
extern tRadioDriver *Radio;
extern void FIRECON(int S1,int S2,int S3,int S4);
extern void IWDG_Feed(void);
extern void Adc_Init(void);
extern void USART3_Config(void);
extern void USART1_Config(void);
extern void adcscan(void);
extern void RxPacket(void);
extern void AT24CXX_Init(void); //��ʼ��IIC
extern u8 AT24CXX_Check(void);
extern void AT24CXX_WriteOneByte(u16 WriteAddr,u8 DataToWrite);
extern void AT24CXX_Write(u16 WriteAddr,u8 *pBuffer,u16 NumToWrite);
extern void AT24CXX_Read(u16 ReadAddr,u8 *pBuffer,u16 NumToRead);
extern int setting_flag;
extern const int num595;
extern unsigned char fire_cahce[];
extern void drv595(unsigned char val595[]);
extern  u32 servo_val[36];
u8 Setting_Buffer[90];
u8 freq_set,freq_set_p;
u8 freq_flag=0,freq_flag2=0;
u8 Setting_Default[]={
	0xba,	
	0x05,0x28,0x05,0x64,0x05,0x46,
	0x05,0x28,0x05,0x64,0x05,0x46,
	0x05,0x28,0x05,0x64,0x05,0x46,
	0x05,0x28,0x05,0x64,0x05,0x46,
	0x05,0x28,0x05,0x64,0x05,0x46,
	0x05,0x28,0x05,0x64,0x05,0x46,
	0x05,0x28,0x05,0x64,0x05,0x46,
	0x05,0x28,0x05,0x64,0x05,0x46,
	0x05,0x28,0x05,0x64,0x05,0x46,
	0x05,0x28,0x05,0x64,0x05,0x46,
	0x05,0x28,0x05,0x64,0x05,0x46,
	0x05,0x28,0x05,0x64,0x05,0x46,
	0x05,0x28,0x05,0x64,0x05,0x46,
	0x05,0x28,0x05,0x64,0x05,0x46,
	0x02,
	0x04,
	0x00
};
void TIM5_Int_Init(u16 arr,u16 psc);
const u8 Setting_Size=sizeof(Setting_Buffer);	
u8 Check_Buffer[Setting_Size];
const u8 ch_dy=7,ch_dir=6;
extern void PWM_Out(u8 ch,uint16_t Compare);
void Setting_rewrite(void);
void Setting_refresh(void);
extern u32 dy_min,dy_mid,dy_max,servo_dir_min,servo_dir_mid,servo_dir_max;
extern void Motor_IO_Init(void);
//,servo1_min,servo1_mid,servo1_max;
// extern u32 servo2_min,servo2_mid,servo2_max,servo3_min,servo3_mid,servo3_max,servo4_min,servo4_mid,servo4_max,servo5_min,servo5_mid,servo5_max;
// extern u32 servo6_min,servo6_mid,servo6_max,servo7_min,servo7_mid,servo7_max,servo8_min,servo8_mid,servo8_max,servo9_min,servo9_mid,servo9_max;
// extern u32 servo10_min,servo10_mid,servo10_max,servo11_min,servo11_mid,servo11_max,servo12_min,servo12_mid,servo12_max;
extern u8 TxBuf[4];
extern uint32_t user_offset;
extern void TIM6_Int_Init(u16 arr,u16 psc);
extern void DS18B20_Init(void);
extern void Usart1_DMA_init(void);
extern u8 USART_RX_BUF[];
