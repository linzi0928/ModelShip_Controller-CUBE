/*************************************************************************************************************
�����ۺϴ������칤����        ��Ʒ
Gearing Interated Shipbuilding Studio

����������غ���(USART1&USART3)

��ע����ID��tnt34 ������¹����ɹ�
��עBվUP���������ۺϴ������� ��ø�����Ƶ��Դ

2017-4-3��һ��
��Ȩ���� ��ֹ�����κ���ҵ��;��
*************************************************************************************************************/
#include "Usart.h"
#include <stdarg.h>
u16 USART_RX_STA=0; 
u8 USART_RX_BUF[20];
u8 SX_TX_BUF[20];
void USART1_Config(void)
{
	
	GPIO_InitTypeDef GPIO_InitStructure;			//���崮�ڽṹ��
	USART_InitTypeDef USART_InitStructure;		//���崮�ڳ�ʼ���ṹ��
	NVIC_InitTypeDef NVIC_InitStructure;
	/* config USART1 clock */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);    

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	  
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No ;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode =  USART_Mode_Tx|USART_Mode_Rx;
	USART_Init(USART1, &USART_InitStructure); 
	
 	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
 	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=3 ;//��ռ���ȼ�3
 	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		//�����ȼ�3
 	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
 	NVIC_Init(&NVIC_InitStructure);	//����ָ���Ĳ�����ʼ��VIC�Ĵ���
    
     USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);//�����ж�
		 USART_DMACmd(USART1,USART_DMAReq_Rx,ENABLE);
	
  USART_Cmd(USART1, ENABLE);
	
	
	
}
void USART3_Config(void)
{
		 GPIO_InitTypeDef GPIO_InitStructure;
		USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
		// Enable the USART3 Interrupt 
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	
	//ʹ�ܴ���3ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
	
	
  USART_InitStructure.USART_BaudRate = 9600;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No ;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  
  USART_Init(USART3, &USART_InitStructure);
  
  //ʹ�ܴ���3����
  USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);

  USART_Cmd(USART3, ENABLE);  

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOB, &GPIO_InitStructure);  
}
int fputc(int ch, FILE *f)
{      
	while(USART_GetFlagStatus(USART1,USART_FLAG_TC)==RESET); 
    USART_SendData(USART1,(uint8_t)ch);   
	return ch;
}
int fgetc(FILE *f)
{ 
   while(!(USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == SET));
	
   return (USART_ReceiveData(USART1));
}

void Usart1_DMA_init()
{
    DMA_InitTypeDef DMA_InitStructure;
	  NVIC_InitTypeDef NVIC_InitStructure;
	
	  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE); //DMA1 ????
	
	  DMA_DeInit(DMA1_Channel5);//?DMA???5?????????  ??1????DMA??5(??)
	  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&USART1->DR;//DMA??UASRT1->DR???
    DMA_InitStructure.DMA_MemoryBaseAddr = (u32)USART_RX_BUF;//DMA?????
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;//DMA??  ??->??
    DMA_InitStructure.DMA_BufferSize = sizeof(USART_RX_BUF);//DMA???DMA?????
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;//???????
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//??????1
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;//?????8?
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;//?????8?
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
    //DMA_Mode_Normal(?????), DMA_Mode_Circular (?????)
    DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;//(DMA????????)
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;//DMA??x????????????
    DMA_Init(DMA1_Channel5, &DMA_InitStructure);//???DMA1 ??5
    DMA_Cmd(DMA1_Channel5, ENABLE);  //??DMA??
	
	  //DMA??????
	  NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel5_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;//?????3
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		//????3
	  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQ????
	  NVIC_Init(&NVIC_InitStructure);	//??????????VIC??? 	
		
		DMA_ITConfig(DMA1_Channel5, DMA_IT_TC, ENABLE);//??DMA??????
}
void DMA1_Channel5_IRQHandler(void)
{
	int xx=0;
if(DMA_GetFlagStatus(DMA1_FLAG_TC5)==SET)
   {
		 
        DMA_ClearFlag(DMA1_FLAG_TC5);
		 for(xx=0;xx<20;xx++)
		 {
		 SX_TX_BUF[xx]=USART_RX_BUF[xx];
		 }
			 // printf(USART_RX_BUF);       
   }
}

//void USART1_IRQHandler(void)                	//����1�жϷ������
//	{
//u8 Res;
//	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)  //�����ж�(���յ������ݱ�����0x0d 0x0a��β)
//		{
//		Res =USART_ReceiveData(USART1);//(USART1->DR);	//��ȡ���յ�������
//		
//		if((USART_RX_STA&0x8000)==0)//����δ���
//			{
//			if(USART_RX_STA&0x4000)//���յ���0x0d
//				{
//				if(Res!=0x0a)USART_RX_STA=0;//���մ���,���¿�ʼ
//				else USART_RX_STA|=0x8000;	//��������� 
//				}
//			else //��û�յ�0X0D
//				{	
//				if(Res==0x0d)USART_RX_STA|=0x4000;
//				else
//					{
//					USART_RX_BUF[USART_RX_STA&0X3FFF]=Res ;
//					USART_RX_STA++;
//					if(USART_RX_STA>(100-1))USART_RX_STA=0;//�������ݴ���,���¿�ʼ����	  
//					}		 
//				}
//			}   		 
//     }
//} 
