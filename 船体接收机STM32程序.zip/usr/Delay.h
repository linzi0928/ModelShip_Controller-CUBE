#ifndef __Delay_H
#define __Delay_H   
#include "stm32f10x.h"
#include "stm32f10x_it.h"


void Delay_us(__IO u32 nTime);    
void Delay_ms(__IO u32 nTime);  
void Delay_s(__IO u32 nTime);    

#endif
