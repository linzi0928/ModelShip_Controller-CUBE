#include "NRF905.h"
#include "Delay.h"

static void NRF905_GPIO_Configuration(void)
{ 
	GPIO_InitTypeDef GPIO_InitStructure,GPIO_InitStructure_FLAG;
	RCC_APB2PeriphClockCmd(FLAG_RCC_APB2Periph_GPIO,ENABLE);

	GPIO_InitStructure_FLAG.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_15;
	GPIO_InitStructure_FLAG.GPIO_Speed = GPIO_Speed_10MHz; 
	GPIO_InitStructure_FLAG.GPIO_Mode = GPIO_Mode_Out_PP; 
	GPIO_Init(FLAG_CONTROL, &GPIO_InitStructure_FLAG); 
	
	GPIO_InitStructure_FLAG.GPIO_Pin = GPIO_Pin_14;
	GPIO_InitStructure_FLAG.GPIO_Speed = GPIO_Speed_10MHz; 
	GPIO_InitStructure_FLAG.GPIO_Mode = GPIO_Mode_IPD; 
	GPIO_Init(FLAG_CONTROL, &GPIO_InitStructure_FLAG); 
	
	
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
	GPIO_Init(GPIOA, &GPIO_InitStructure); 
	
	//GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(NRF905_RCC_APB2Periph_GPIO,ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_3|GPIO_Pin_0|GPIO_Pin_13 |GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_15 |GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
	GPIO_Init(NRF905_GPIO_CONTROL, &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_14|GPIO_Pin_6|GPIO_Pin_7; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; 
	GPIO_Init(NRF905_GPIO_CONTROL, &GPIO_InitStructure);
	
}
