#include "stm32f10x.h"
#include "delay.h"
#include "sys.h"
#include "timer.h"
#include "Usart.h"
#include "stm32f10x_adc.h"
#include "Delay.h"
 #include "adc.h"
 #include "DS18B20.h"
#include "sys_config.h"
void Delay(__IO uint32_t nCount);
void Flow_Test(void);
void GPIO_Configuration(void);
/* Private functions ---------------------------------------------------------*/
void Key_test(void);
void SpiWrite(u8 byte);
		int d[1]={0x00};
		u8 px[30];
		u16 adcx,adcx2;
		float temp,temp2;   	 //��ʱ������ʼ��	  
void	NVIC_Configuration(void);
void TIM3_PWM_Init(u16 arr,u16 psc);
void TIM4_PWM_Init(u16 arr,u16 psc);
void TIM_SetCompare2(TIM_TypeDef* TIMx, uint16_t Compare2);
		void TIM_Cmd(TIM_TypeDef* TIMx, FunctionalState NewState);
void TIM2_PWM_Init(u16 arr,u16 psc);
extern void Adc_Init(void);
		
		
		
#define BUFFER_SIZE     30                          // Define the payload size here
static uint16_t BufferSize = BUFFER_SIZE;			// RF buffer size
tRadioDriver *Radio = NULL;
void	BoardInit(void);
#define SX1278_RX////////////////////////////////////////////////////////////////////////////////////////////
		
		
	
void adcscan()
{
	adcx=Get_Adc_Average(ADC_Channel_2,10);
		adcx2=Get_Adc_Average(ADC_Channel_3,10);
		temp=(float)adcx*(3.3/1024);
		temp2=(float)adcx2*(3.3/100);
	adcx=temp*10;
		adcx2=temp2*10;
}
u32 c=0;
u32 temper=0;
u16 tservo=0;
void senddata()
{
	while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
	USART_SendData(USART1,temper/10);
	while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
	USART_SendData(USART1,adcx+1);
	while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
	USART_SendData(USART1,adcx2);
	while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
	USART_SendData(USART1,13);
	while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
	USART_SendData(USART1,10);
}
void GPIO_Init_Gen()
{
	GPIO_InitTypeDef  GPIO_InitStructure;

	//enable GPIO clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOA,ENABLE);

	//Configure TX_EN , TRX_CE , PWR_UP ,pin as output:  
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 	//�������
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; 	//�������
	GPIO_Init(GPIOB,&GPIO_InitStructure);

	//Configure AM , DR , CM  pins as input pin to be detected
	
			GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 	//�������
	GPIO_Init(GPIOC,&GPIO_InitStructure);
	
			GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 	//�������
	GPIO_Init(GPIOA,&GPIO_InitStructure);
}
int main(void)
{
	 	u16 led0pwmval=0,servo=0;
	
		uint8_t i;

	sys_Configuration();
	BoardInit( );
  Radio = RadioDriverInit( );
  Radio->Init( );
  Radio->StartRx( );   //RFLR_STATE_RX_INIT
	
	
	
   GPIO_Init_Gen();
	PAout(4)=1;
	PAout(5)=1;
PEout(5)=1;	
	USART1_Config();
		Adc_Init();		  		//ADC��ʼ��
		NVIC_Configuration();
	TIM3_PWM_Init(1440,1000);		
	TIM2_PWM_Init(1440,1000);
	TIM4_PWM_Init(1440,1000);
	led0pwmval=1353;
	TIM_SetCompare2(TIM3,led0pwmval);	
	adcscan();
	senddata();
	//delay_ms(1000);	
  while (1)
  {
		c++;
		if(c>900)
		{
			c=0;
		adcscan();
		temper=DS18B20_Get_Temp();	
		senddata();
		}


		
  while( Radio->Process( ) == RF_RX_DONE)
		{
			for(i=0;i<BUFFER_SIZE;i++)
			px[i] = 0;
			Radio->GetRxPacket( px, ( uint16_t* )&BufferSize );
				LED0_TOGGLE;
			Delay_ms(2);
			Radio->StartRx( );
		}
		
		
		//	delay_ms(100);
		/*	PEout(5)=0;
			delay_ms(*(px+1)*10);
			PEout(5)=1;
			delay_ms(*(px+1)*10);*/
		
		
		
		led0pwmval=((*(px+2))*0.5648855);
		servo=(32-(*(px+1)))*1.8+1324;
		/*if(servo>1400)
			servo=1350;*/
	TIM_SetCompare2(TIM2,servo-15);
		if(servo<1335)
		{
			tservo=1335;
		}
		else
			tservo=servo;
	TIM_SetCompare2(TIM4,tservo+10);
		Delay_ms(4);
		if((*(px+3))==0x05)
		{
		TIM_SetCompare2(TIM3,1352+(led0pwmval*0.4));	
		}
		if(*(px)==0x05)
		{
			TIM_SetCompare2(TIM3,1354-led0pwmval);	
		}
		if(*(px+4)==0x05)
		PCout(14)=0;
		else PCout(14)=1;
		if(*(px+5)==0x05)
		PCout(15)=0;
		else PCout(15)=1;
		
		
		if(*(px+6)==0x05)
		PAout(4)=0;
		else PAout(4)=1;
		if(*(px+7)==0x05)
		PAout(5)=0;
		else PAout(5)=1;
		Delay_ms(1);
		
		
		
		/*	if(*(px+5)==0x05)
				PEout(5)=1;
			else PEout(5)=0;*/
		
  }
}
