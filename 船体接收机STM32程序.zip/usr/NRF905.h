/***********************************************************
*   ������˵����NRF905��������                            
*   ���ߣ�      King_BingGe                                       
*   �������ڣ�  2013��04��17��   
*		˵��������IC��NRF905					 
*
***********************************************************/
#define __NRF905_H
#include "stm32f10x.h"
#include "stdio.h"


#define FLAG_CONTROL	GPIOC
#define FLAG_RCC_APB2Periph_GPIO RCC_APB2Periph_GPIOC
#define FLAG_ON GPIO_ResetBits(FLAG_CONTROL, GPIO_Pin_13)
#define FLAG_OFF GPIO_SetBits(FLAG_CONTROL, GPIO_Pin_13)

#define NRF905_GPIO_CONTROL	GPIOB
#define NRF905_RCC_APB2Periph_GPIO RCC_APB2Periph_GPIOB

#define NRF905_TX_EN_L GPIO_ResetBits(NRF905_GPIO_CONTROL, GPIO_Pin_4)
#define NRF905_TX_EN_H GPIO_SetBits(NRF905_GPIO_CONTROL, GPIO_Pin_4)

#define NRF905_TRX_CE_L GPIO_ResetBits(NRF905_GPIO_CONTROL, GPIO_Pin_0)
#define NRF905_TRX_CE_H GPIO_SetBits(NRF905_GPIO_CONTROL, GPIO_Pin_0)

#define NRF905_PWR_UP_L GPIO_ResetBits(NRF905_GPIO_CONTROL, GPIO_Pin_5)
#define NRF905_PWR_UP_H GPIO_SetBits(NRF905_GPIO_CONTROL, GPIO_Pin_5)

#define NRF905_MOSI_L GPIO_ResetBits(NRF905_GPIO_CONTROL, GPIO_Pin_15)
#define NRF905_MOSI_H GPIO_SetBits(NRF905_GPIO_CONTROL, GPIO_Pin_15)

#define NRF905_SCK_L GPIO_ResetBits(NRF905_GPIO_CONTROL, GPIO_Pin_13)
#define NRF905_SCK_H GPIO_SetBits(NRF905_GPIO_CONTROL, GPIO_Pin_13)

#define NRF905_CSN_L GPIO_ResetBits(NRF905_GPIO_CONTROL, GPIO_Pin_12)
#define NRF905_CSN_H GPIO_SetBits(NRF905_GPIO_CONTROL, GPIO_Pin_12)

#define NRF905_CD_DATA GPIO_ReadInputDataBit(NRF905_GPIO_CONTROL, GPIO_Pin_6)
#define NRF905_AM_DATA GPIO_ReadInputDataBit(NRF905_GPIO_CONTROL, GPIO_Pin_1)
#define NRF905_DR_DATA GPIO_ReadInputDataBit(NRF905_GPIO_CONTROL, GPIO_Pin_7)
#define NRF905_MISO_DATA GPIO_ReadInputDataBit(NRF905_GPIO_CONTROL, GPIO_Pin_14)

#define NRF905_AM_DATA_L GPIO_WriteBit(NRF905_GPIO_CONTROL,GPIO_Pin_1, Bit_RESET)
#define NRF905_DR_DATA_L GPIO_WriteBit(NRF905_GPIO_CONTROL,GPIO_Pin_7, Bit_RESET)

