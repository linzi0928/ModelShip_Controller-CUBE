/*************************************************************************************************************
�����ۺϵ��ӹ�����(GIE������)        ��Ʒ
Gearing Interated Electronics Studio

�Ա���������С��������ĸ��Ŀ��ƺ�������ʵ���Զ����ֶ���ͬʱ��ת��ִ��

��עBվUP����GIE������ ��ø�����Ƶ��Դ����̬

2020-8-12��һ��
��Ȩ���� ��ֹδ�����������κ���ҵ��;��
*************************************************************************************************************/
#include "MOTOR.H"
#include "delay.h"
int ConnectFlag=0;
int TIMC_Flag=0,TIMC_Flag2=0,TIMC_Flag3=0,TIMC_Flag4=0;
int CTx,CTy,CTw,CTz,len,sflag=1,CTR2,CTR3,CTR4;
long int targetX=0,targetY=0,targetZ=0,targetW=0,OpMode=0;
int exflag=0;
void Motor_IO_Init()//���������ӦIO��ʼ��
{

//  GPIO_InitTypeDef  GPIO_InitStructure;
//  	
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOF|RCC_APB2Periph_GPIOG|RCC_APB2Periph_GPIOE, ENABLE);
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11|GPIO_Pin_10;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
//  GPIO_Init(GPIOB, &GPIO_InitStructure);
//  
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_0;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
//  GPIO_Init(GPIOG, &GPIO_InitStructure);

//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15|GPIO_Pin_14|GPIO_Pin_13|GPIO_Pin_12|GPIO_Pin_11|GPIO_Pin_10|GPIO_Pin_9|GPIO_Pin_8|GPIO_Pin_7;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
//  GPIO_Init(GPIOE, &GPIO_InitStructure);
// 	
//  GPIO_InitStructure.GPIO_Pin =GPIO_Pin_15|GPIO_Pin_14|GPIO_Pin_13 ;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
//  GPIO_Init(GPIOF, &GPIO_InitStructure);

}
void Auto_Step_to(int W,int Z,int Y,int X)//�Զ�ģʽ�£�����Ӧ����������ж�Ӧ����������ִ����Ϻ�d_flag����0��ִ����Ϊ1
{
	d_flag=0;
	if (X-CTx>0&&((Setting_Buffer[88]>>4)!=4)&&(Setting_Buffer[88]&0x0f)!=4)
	{
		One_Step(0);//3
		d_flag=1;
	}
	else if (X-CTx<0&&((Setting_Buffer[88]>>4)!=4)&&(Setting_Buffer[88]&0x0f)!=4)
	{
		One_Step(1);
		d_flag=1;
	}
	
	if (Y-CTy>0&&((Setting_Buffer[88]>>4)!=3)&&(Setting_Buffer[88]&0x0f)!=3)
	{
		One_Step(2);//2
		d_flag=1;
	}
	else if (Y-CTy<0&&((Setting_Buffer[88]>>4)!=3)&&(Setting_Buffer[88]&0x0f)!=3)
	{
		One_Step(3);
		d_flag=1;
	}


	if (Z-CTz>0&&((Setting_Buffer[88]>>4)!=2)&&(Setting_Buffer[88]&0x0f)!=2)
	{
		One_Step(4);//4
		d_flag=1;
	}
	else if (Z-CTz<0&&((Setting_Buffer[88]>>4)!=2)&&(Setting_Buffer[88]&0x0f)!=2)
	{
		One_Step(5);
		d_flag=1;
	}	
	if (W-CTw>0&&((Setting_Buffer[88]>>4)!=1)&&(Setting_Buffer[88]&0x0f)!=1)
	{
		One_Step(6);//1
		d_flag=1;
	}
	else if (W-CTw<0&&((Setting_Buffer[88]>>4)!=1)&&(Setting_Buffer[88]&0x0f)!=1)
	{
		One_Step(7);
		d_flag=1;
	}	
}
void Motor_Init()//���������ʼ����������ִ����Ϻ���ִ�б���������������������(��Ӧ���·)
{
	if(((Setting_Buffer[88]>>4)!=4)&&(Setting_Buffer[88]&0x0f)!=4)
	{
	MX0 = 0;
  MX1 = 0;		    
  MX2 = 0;
  MX3 = 0;
	}
	if(((Setting_Buffer[88]>>4)!=3)&&(Setting_Buffer[88]&0x0f)!=3)
	{
	MY0 = 0;
  MY1 = 0;
  MY2 = 0;
  MY3 = 0;	
	}
	if(((Setting_Buffer[88]>>4)!=2)&&(Setting_Buffer[88]&0x0f)!=2)
	{
	MZ0 = 0;
  MZ1 = 0;
  MZ2 = 0;
  MZ3 = 0;
	}		
	if(((Setting_Buffer[88]>>4)!=1)&&(Setting_Buffer[88]&0x0f)!=1)
	{
	MW0 = 0;
  MW1 = 0;
  MW2 = 0;
  MW3 = 0;	
	}
}
void MOTOR_Handler()//���������߼�����������ң����Ϣ���Ʋ�������ֶ������Զ�
{
		if(((*(px+11))<<8)+(*(px+12))==0x3e7)//������ֵΪ65534ʱΪ�ֶ�ģʽ�������ҡ�˶����������
		{
			if((    ((((*(px+10))&0x03)==0x01)&&((*(px+5))<30))  ||  ((((*(px+10))&0x03)==0x02)&&((*(px+5))>70))  )&&((Setting_Buffer[88]>>4)!=1)&&(Setting_Buffer[88]&0x0f)!=1)//��11λ�洢��Ϊ�ĸ������ѡ����λ16��������Ӧ8λ������������λ�����Ʊ�ʾһ���������Ϊ01ʱ��ת��10ʱ��ת��11ʱͣת
			One_Step(7);
			else if((    ((((*(px+10))&0x03)==0x02)&&((*(px+5))<30))  ||  ((((*(px+10))&0x03)==0x01)&&((*(px+5))>70))  )&&((Setting_Buffer[88]>>4)!=1)&&(Setting_Buffer[88]&0x0f)!=1)//���ð�λ������޳�����ͨ��������жϱ�ͨ��״̬
			One_Step(6);
			if((    ((((*(px+10))&0x0c)==0x04)&&((*(px+5))<30))  ||  ((((*(px+10))&0x0c)==0x08)&&((*(px+5))>70))  )&&((Setting_Buffer[88]>>4)!=2)&&(Setting_Buffer[88]&0x0f)!=2)
			One_Step(5);
			else if((    ((((*(px+10))&0x0c)==0x08)&&((*(px+5))<30))  ||  ((((*(px+10))&0x0c)==0x04)&&((*(px+5))>70))  )&&((Setting_Buffer[88]>>4)!=2)&&(Setting_Buffer[88]&0x0f)!=2)
			One_Step(4);
			if((    ((((*(px+10))&0x30)==0x10)&&((*(px+5))<30))  ||  ((((*(px+10))&0x30)==0x20)&&((*(px+5))>70))  )&&((Setting_Buffer[88]>>4)!=3)&&(Setting_Buffer[88]&0x0f)!=3)
			One_Step(3);
			else if((    ((((*(px+10))&0x30)==0x20)&&((*(px+5))<30))  ||  ((((*(px+10))&0x30)==0x10)&&((*(px+5))>70))  )&&((Setting_Buffer[88]>>4)!=3)&&(Setting_Buffer[88]&0x0f)!=3)
			One_Step(2);
			if((    ((((*(px+10))&0xc0)==0x40)&&((*(px+5))<30))  ||  ((((*(px+10))&0xc0)==0x80)&&((*(px+5))>70))  )&&((Setting_Buffer[88]>>4)!=4)&&(Setting_Buffer[88]&0x0f)!=4)//step4
			One_Step(0);
			else if((    ((((*(px+10))&0xc0)==0x80)&&((*(px+5))<30))  ||  ((((*(px+10))&0xc0)==0x40)&&((*(px+5))>70))  )&&((Setting_Buffer[88]>>4)!=4)&&(Setting_Buffer[88]&0x0f)!=4)
			One_Step(1);
			if((*(px+5))>45&&(*(px+5))<55)
			Motor_Init();//��ȫ����Ϊͣת״̬ʱ��ʱ������ĸ���λ�������ⷢ��
		}
//		else if(((*(px+10))!=0xff)&&(((*(px+10))&0xc0)!=0)&&(fflag==0))//����11λ��Ϊ0xff�����е����ת������ɱ�־��Ϊ1ʱ����ִ���Զ�ģʽ
//		{		

//			if(((*(px+10))&0x03)==0x01)//��ң��������ȡ������ֵ����λ�洢һ������Ĳ���ֵ
//				targetX=-phy_offset*(((*(px+12))<<8)+(*(px+13)));
//			else if(((*(px+10))&0x03)==0x02)
//				targetX=phy_offset*(((*(px+12))<<8)+(*(px+13)));
//			if(((*(px+10))&0x0c)==0x04)
//				targetY=-phy_offset*(((*(px+14))<<8)+(*(px+15)));
//			else if(((*(px+10))&0x0c)==0x08)
//				targetY=phy_offset*(((*(px+14))<<8)+(*(px+15)));
//			if(((*(px+10))&0x30)==0x10)
//				targetZ=-phy_offset*(((*(px+16))<<8)+(*(px+17)));
//			else if(((*(px+10))&0x30)==0x20)
//				targetZ=phy_offset*(((*(px+16))<<8)+(*(px+17)));
//			if(((*(px+10))&0xc0)==0x40)
//				targetW=phy_offset*(((*(px+18))<<8)+(*(px+19)));
//			else if(((*(px+10))&0xc0)==0x80)
//				targetW=-phy_offset*(((*(px+18))<<8)+(*(px+19)));

//		Auto_Step_to(targetX,targetY,targetZ,targetW);		//ִ���Զ�
//			if(d_flag==0)
//			{
//			CTx=0;CTy=0;CTz=0;CTw=0;fflag=1;//��ִ����Ϻ󽫶�Ӧ����ʱ�������㣬��ɱ�־��1
//			}
//		if(((*(px+11))&0x03)==0x03&&(((Setting_Buffer[88]>>4)!=1)&&(Setting_Buffer[88]&0x0f)!=1))//���е�λδѡ��ʱ��ʱ��0����������ǲ���ת��
//				{MW0 = 0;MW1 = 0;MW2 = 0;MW3 = 0;}
//		if(((*(px+11))&0x0c)==0x0c&&(((Setting_Buffer[88]>>4)!=2)&&(Setting_Buffer[88]&0x0f)!=2))
//				{MZ0 = 0;MZ1 = 0;MZ2 = 0;MZ3 = 0;}
//		if(((*(px+11))&0x30)==0x30&&(((Setting_Buffer[88]>>4)!=3)&&(Setting_Buffer[88]&0x0f)!=3))
//				{MY0 = 0;MY1 = 0;MY2 = 0;MY3 = 0;}
//		if(((*(px+11))&0xc0)==0xc0&&(((Setting_Buffer[88]>>4)!=4)&&(Setting_Buffer[88]&0x0f)!=4))
//				{MX0 = 0;MX1 = 0;MX2 = 0;MX3 = 0;}
//		if(fflag==1)
//			Motor_Init();//��ɱ�־��1��ʱ��ʼ��������ⷢ��
//		}
		else if((*(px+10))==0xff)
		{fflag=0;CTx=0;CTy=0;CTz=0;CTw=0;Motor_Init();}
}
void MOTOR_Handler_const(void)//��ת������������
{
	if((Setting_Buffer[88]>>4)<5)
	{
			if(((Setting_Buffer[88]>>4)==1)&&((Setting_Buffer[87]>>7)==1))
			One_Step(7);
			else if(((Setting_Buffer[88]>>4)==1)&&((Setting_Buffer[87]>>7)==0))
			One_Step(6);
			if(((Setting_Buffer[88]>>4)==2)&&((Setting_Buffer[87]>>7)==1))
			One_Step(5);
			else if(((Setting_Buffer[88]>>4)==2)&&((Setting_Buffer[87]>>7)==0))
			One_Step(4);
			if(((Setting_Buffer[88]>>4)==3)&&((Setting_Buffer[87]>>7)==1))
			One_Step(3);
			else if(((Setting_Buffer[88]>>4)==3)&&((Setting_Buffer[87]>>7)==0))
			One_Step(2);
			if(((Setting_Buffer[88]>>4)==4)&&((Setting_Buffer[87]>>7)==1))
			One_Step(0);
			else if(((Setting_Buffer[88]>>4)==4)&&((Setting_Buffer[87]>>7)==0))
			One_Step(1);
	}
	if((Setting_Buffer[88]&0x0f)<5)
	{
			if(((Setting_Buffer[88]&0x0f)==1)&&(((Setting_Buffer[87]>>6)&0x01)==1))
			One_Step(7);
			else if(((Setting_Buffer[88]&0x0f)==1)&&(((Setting_Buffer[87]>>6)&0x01)==0))
			One_Step(6);
			if(((Setting_Buffer[88]&0x0f)==2)&&(((Setting_Buffer[87]>>6)&0x01)==1))
			One_Step(5);
			else if(((Setting_Buffer[88]&0x0f)==2)&&(((Setting_Buffer[87]>>6)&0x01)==0))
			One_Step(4);
			if(((Setting_Buffer[88]&0x0f)==3)&&(((Setting_Buffer[87]>>6)&0x01)==1))
			One_Step(3);
			else if(((Setting_Buffer[88]&0x0f)==3)&&(((Setting_Buffer[87]>>6)&0x01)==0))
			One_Step(2);
			if(((Setting_Buffer[88]&0x0f)==4)&&(((Setting_Buffer[87]>>6)&0x01)==1))
			One_Step(0);
			else if(((Setting_Buffer[88]&0x0f)==4)&&(((Setting_Buffer[87]>>6)&0x01)==0))
			One_Step(1);
	}
	if(px[13]==0)
	Motor_Init();
}
void Ex_motor_Handler()
{
	int pix=11;
	if(refresh_flag!=refresh_flag_old)
	{
		refresh_flag_old=refresh_flag;
		if((px[31]==2)||(px[31]==3))
		{
			while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
			USART_SendData(USART1,0xaf);
			for(pix=11;pix<=19;pix++)
			{
			while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
			USART_SendData(USART1,px[pix]);
			}
			while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
			USART_SendData(USART1,px[31]);
			while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
			USART_SendData(USART1,pow(2,(px[28]>>4)));
			while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
			USART_SendData(USART1,13);
			while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
			USART_SendData(USART1,10);
		}
	}
}
void One_Step(int dir)//���������������������ʵ���벻��������д������������ĺ�������Ϳ���=.=��0-X��ת��1-X��ת��2-Y��ת��3-Y��ת��4-Z��ת��5-Z��ת��6-W��ת��7-W��ת��
{
if(dir==0)
	{
	switch(CTR)
    {
       case 0:
          if(TIMC_Flag)   // ���ж�����1�ı�־λ�����ɽ�����һ�ģ��������ܰ��ж��ٶ�һ��һ�ĵ���ת
          {				    
            MX0 = 0;		    //0xf1  
            MX1 = 1;
						MX2 = 1;
            MX3 = 1;
            CTR = 1;
						CTx++;
						TIMC_Flag=0;
          }
       break;

       case 1:		 // AB
         if(TIMC_Flag)
          {	
            MX0 = 0;		   //0xf3 
            MX1 = 0;
           	MX2 = 1;
            MX3 = 1;
            CTR = 2;
						CTx++;
			TIMC_Flag=0;
          }
       break;

       case 2:	   //B
         if(TIMC_Flag)
          {
           
          	MX0 = 1;
            MX1 = 0;		  //0xf2 
            MX2 = 1;
            MX3 = 1;
           CTx++;
            CTR = 3;
			TIMC_Flag=0;
          }
       break;


       case 3:		//BC
         if(TIMC_Flag)
          {	
            MX0 = 1;
            MX1 = 0;		    //0xf6
            MX2 = 0;
            MX3 = 1;
            CTR = 4;
						CTx++;
			TIMC_Flag=0;
          }
       break;
     case 4:		 //C
         if(TIMC_Flag)
          {	
            MX0 = 1;
            MX1 = 1;		    //0xf4
            MX2 = 0;
            MX3 = 1;
            CTR = 5;
						CTx++;
			TIMC_Flag=0;
           }
       break;
	case 5:			  //CD
         if(TIMC_Flag)
          {	
            MX0 = 1;
            MX1 = 1;		    //0xfc
            MX2 = 0;
            MX3 = 0;
            CTR = 6;
						CTx++;
			TIMC_Flag=0;
          }
       break;
	case 6:			  //D
         if(TIMC_Flag)
          {	
            MX0 = 1;
            MX1 = 1;		    //0xf8
            MX2 = 1;
            MX3 = 0;
            CTR = 7;
						CTx++;
			TIMC_Flag=0;
          }
       break;
	case 7:			//DA
         if(TIMC_Flag)
          {	
            MX0 = 0;
            MX1 = 1;		    //0xf9
            MX2 = 1;
            MX3 = 0;
            CTR = 0;
						CTx++;
			TIMC_Flag=0;
          }
       break;
	}
 }
 if(dir==1)
	{
	switch(CTR)
    {
       case 0:
          if(TIMC_Flag)   // A
          {				    
            MX0 = 0;		    //0xf1             0111 0011 1011 1001 1101 1100 1110 0110
            MX1 = 1;
						MX2 = 1;
            MX3 = 0;
						CTx--;
            CTR = 1;
			TIMC_Flag=0;
          }
       break;

       case 1:		 // AB
         if(TIMC_Flag)
          {	
            MX0 = 1;		   //0xf3 
            MX1 = 1;
           	MX2 = 1;
            MX3 = 0;
						CTx--;
            CTR = 2;
			TIMC_Flag=0;
          }
       break;

       case 2:	   //B
         if(TIMC_Flag)
          {
           
          	MX0 = 1;
            MX1 = 1;		  //0xf2 
            MX2 = 0;
            MX3 = 0;
           CTx--;
            CTR = 3;
			TIMC_Flag=0;
          }
       break;


       case 3:		//BC
         if(TIMC_Flag)
          {	
            MX0 = 1;
            MX1 = 1;		    //0xf6
            MX2 = 0;
            MX3 = 1;
						CTx--;
            CTR = 4;
			TIMC_Flag=0;
          }
       break;
     case 4:		 //C
         if(TIMC_Flag)
          {	
            MX0 = 1;
            MX1 = 0;		    //0xf4
            MX2 = 0;
            MX3 = 1;
						CTx--;
            CTR = 5;
			TIMC_Flag=0;
           }
       break;
	case 5:			  //CD
         if(TIMC_Flag)
          {	
            MX0 = 1;
            MX1 = 0;		    //0xfc
            MX2 = 1;
            MX3 = 1;
						CTx--;
            CTR = 6;
			TIMC_Flag=0;
          }
       break;
	case 6:			  //D
         if(TIMC_Flag)
          {	
            MX0 = 0;
            MX1 = 0;		    //0xf8
            MX2 = 1;
            MX3 = 1;
						CTx--;
            CTR = 7;
			TIMC_Flag=0;
          }
       break;
	case 7:			//DA
         if(TIMC_Flag)
          {	
            MX0 = 0;
            MX1 = 1;		    //0xf9
            MX2 = 1;
            MX3 = 1;
						CTx--;
            CTR = 0;
			TIMC_Flag=0;
          }
       break;
	}
 }
 	if(dir==2)
	{
		switch(CTR2)
    {
       case 0:
          if(TIMC_Flag2)   // A
          {				    
            MY0 = 0;		    //0xf1             0111 0011 1011 1001 1101 1100 1110 0110
            MY1 = 1;
						MY2 = 1;
            MY3 = 0;
						CTy++;
            CTR2 = 1;
			TIMC_Flag2=0;
          }
       break;

       case 1:		 // AB
         if(TIMC_Flag2)
          {	
            MY0 = 1;		   //0xf3 
            MY1 = 1;
           	MY2 = 1;
            MY3 = 0;
						CTy++;
            CTR2 = 2;
			TIMC_Flag2=0;
          }
       break;

       case 2:	   //B
         if(TIMC_Flag2)
          {
           
          	MY0 = 1;
            MY1 = 1;		  //0xf2 
            MY2 = 0;
            MY3 = 0;
           CTy++;
            CTR2 = 3;
			TIMC_Flag2=0;
          }
       break;


       case 3:		//BC
         if(TIMC_Flag2)
          {	
            MY0 = 1;
            MY1 = 1;		    //0xf6
            MY2 = 0;
            MY3 = 1;
						CTy++;
            CTR2 = 4;
			TIMC_Flag2=0;
          }
       break;
     case 4:		 //C
         if(TIMC_Flag2)
          {	
            MY0 = 1;
            MY1 = 0;		    //0xf4
            MY2 = 0;
            MY3 = 1;
						CTy++;
            CTR2 = 5;
			TIMC_Flag2=0;
           }
       break;
	case 5:			  //CD
         if(TIMC_Flag2)
          {	
            MY0 = 1;
            MY1 = 0;		    //0xfc
            MY2 = 1;
            MY3 = 1;
						CTy++;
            CTR2 = 6;
			TIMC_Flag2=0;
          }
       break;
	case 6:			  //D
         if(TIMC_Flag2)
          {	
            MY0 = 0;
            MY1 = 0;		    //0xf8
            MY2 = 1;
            MY3 = 1;
						CTy++;
            CTR2 = 7;
			TIMC_Flag2=0;
          }
       break;
	case 7:			//DA
         if(TIMC_Flag2)
          {	
            MY0 = 0;
            MY1 = 1;		    //0xf9
            MY2 = 1;
            MY3 = 1;
						CTy++;
            CTR2 = 0;
			TIMC_Flag2=0;
          }
       break;
			}
}
	if(dir==3)
	{
		switch(CTR2)
			{
       case 0:
          if(TIMC_Flag2)   // A
          {				    
            MY0 = 0;		    //0xf1  
            MY1 = 1;
						MY2 = 1;
            MY3 = 1;
						CTy--;
            CTR2 = 1;
			TIMC_Flag2=0;
          }
       break;

       case 1:		 // AB
         if(TIMC_Flag2)
          {	
            MY0 = 0;		   //0xf3 
            MY1 = 0;
           	MY2 = 1;
            MY3 = 1;
						CTy--;
            CTR2 = 2;
			TIMC_Flag2=0;
          }
       break;

       case 2:	   //B
         if(TIMC_Flag2)
          {
           
          	MY0 = 1;
            MY1 = 0;		  //0xf2 
            MY2 = 1;
            MY3 = 1;
						CTy--;
            CTR2 = 3;
			TIMC_Flag2=0;
          }
       break;


       case 3:		//BC
         if(TIMC_Flag2)
          {	
            MY0 = 1;
            MY1 = 0;		    //0xf6
            MY2 = 0;
            MY3 = 1;
						CTy--;
            CTR2 = 4;
			TIMC_Flag2=0;
          }
       break;
     case 4:		 //C
         if(TIMC_Flag2)
          {	
            MY0 = 1;
            MY1 = 1;		    //0xf4
            MY2 = 0;
            MY3 = 1;
						CTy--;
            CTR2 = 5;
			TIMC_Flag2=0;
           }
       break;
	case 5:			  //CD
         if(TIMC_Flag2)
          {	
            MY0 = 1;
            MY1 = 1;		    //0xfc
            MY2 = 0;
            MY3 = 0;
						CTy--;
            CTR2 = 6;
			TIMC_Flag2=0;
          }
       break;
	case 6:			  //D
         if(TIMC_Flag2)
          {	
            MY0 = 1;
            MY1 = 1;		    //0xf8
            MY2 = 1;
            MY3 = 0;
						CTy--;
            CTR2 = 7;
			TIMC_Flag2=0;
          }
       break;
	case 7:			//DA
         if(TIMC_Flag2)
          {	
            MY0 = 0;
            MY1 = 1;		    //0xf9
            MY2 = 1;
            MY3 = 0;
						CTy--;
            CTR2 = 0;
			TIMC_Flag2=0;
          }
       break;
	
		}
	}
	
	
	 	if(dir==4)
	{
		switch(CTR3)
    {
       case 0:
          if(TIMC_Flag3)   // A
          {				    
            MZ0 = 0;		    //0xf1             0111 0011 1011 1001 1101 1100 1110 0110
            MZ1 = 1;
						MZ2 = 1;
            MZ3 = 0;
						CTz++;
            CTR3 = 1;
			TIMC_Flag3=0;
          }
       break;

       case 1:		 // AB
         if(TIMC_Flag3)
          {	
            MZ0 = 1;		   //0xf3 
            MZ1 = 1;
           	MZ2 = 1;
            MZ3 = 0;
						CTz++;
            CTR3 = 2;
			TIMC_Flag3=0;
          }
       break;

       case 2:	   //B
         if(TIMC_Flag3)
          {
           
          	MZ0 = 1;
            MZ1 = 1;		  //0xf2 
            MZ2 = 0;
            MZ3 = 0;
           CTz++;
            CTR3 = 3;
			TIMC_Flag3=0;
          }
       break;


       case 3:		//BC
         if(TIMC_Flag3)
          {	
            MZ0 = 1;
            MZ1 = 1;		    //0xf6
            MZ2 = 0;
            MZ3 = 1;
						CTz++;
            CTR3 = 4;
			TIMC_Flag3=0;
          }
       break;
     case 4:		 //C
         if(TIMC_Flag3)
          {	
            MZ0 = 1;
            MZ1 = 0;		    //0xf4
            MZ2 = 0;
            MZ3 = 1;
						CTz++;
            CTR3 = 5;
			TIMC_Flag3=0;
           }
       break;
	case 5:			  //CD
         if(TIMC_Flag3)
          {	
            MZ0 = 1;
            MZ1 = 0;		    //0xfc
            MZ2 = 1;
            MZ3 = 1;
						CTz++;
            CTR3 = 6;
			TIMC_Flag3=0;
          }
       break;
	case 6:			  //D
         if(TIMC_Flag3)
          {	
            MZ0 = 0;
            MZ1 = 0;		    //0xf8
            MZ2 = 1;
            MZ3 = 1;
						CTz++;
            CTR3 = 7;
			TIMC_Flag3=0;
          }
       break;
	case 7:			//DA
         if(TIMC_Flag3)
          {	
            MZ0 = 0;
            MZ1 = 1;		    //0xf9
            MZ2 = 1;
            MZ3 = 1;
						CTz++;
            CTR3 = 0;
			TIMC_Flag3=0;
          }
       break;
			}
	}
	
		 	if(dir==5)
	{
		switch(CTR3)
    {
       case 0:
          if(TIMC_Flag3)   // A
          {				    
            MZ0 = 0;		    //0xf1             0111 0011 1011 1001 1101 1100 1110 0110
            MZ1 = 1;
						MZ2 = 1;
            MZ3 = 1;
						CTz--;
            CTR3 = 1;
			TIMC_Flag3=0;
          }
       break;

       case 1:		 // AB
         if(TIMC_Flag3)
          {	
            MZ0 = 0;		   //0xf3 
            MZ1 = 0;
           	MZ2 = 1;
            MZ3 = 1;
						CTz--;
            CTR3 = 2;
			TIMC_Flag3=0;
          }
       break;

       case 2:	   //B
         if(TIMC_Flag3)
          {
           
          	MZ0 = 1;
            MZ1 = 0;		  //0xf2 
            MZ2 = 1;
            MZ3 = 1;
           CTz--;
            CTR3 = 3;
			TIMC_Flag3=0;
          }
       break;


       case 3:		//BC
         if(TIMC_Flag3)
          {	
            MZ0 = 1;
            MZ1 = 0;		    //0xf6
            MZ2 = 0;
            MZ3 = 1;
						CTz--;
            CTR3 = 4;
			TIMC_Flag3=0;
          }
       break;
     case 4:		 //C
         if(TIMC_Flag3)
          {	
            MZ0 = 1;
            MZ1 = 1;		    //0xf4
            MZ2 = 0;
            MZ3 = 1;
						CTz--;
            CTR3 = 5;
			TIMC_Flag3=0;
           }
       break;
	case 5:			  //CD
         if(TIMC_Flag3)
          {	
            MZ0 = 1;
            MZ1 = 1;		    //0xfc
            MZ2 = 0;
            MZ3 = 0;
						CTz--;
            CTR3 = 6;
			TIMC_Flag3=0;
          }
       break;
	case 6:			  //D
         if(TIMC_Flag3)
          {	
            MZ0 = 1;
            MZ1 = 1;		    //0xf8
            MZ2 = 1;
            MZ3 = 0;
						CTz--;
            CTR3 = 7;
			TIMC_Flag3=0;
          }
       break;
	case 7:			//DA
         if(TIMC_Flag3)
          {	
            MZ0 = 0;
            MZ1 = 1;		    //0xf9
            MZ2 = 1;
            MZ3 = 0;
						CTz--;
            CTR3 = 0;
			TIMC_Flag3=0;
          }
       break;
			}
	}
	
	if(dir==6)
	{
		switch(CTR4)
    {
       case 0:
          if(TIMC_Flag4)   // A
          {				    
            MW0 = 0;		    //0xf1             0111 0011 1011 1001 1101 1100 1110 0110
            MW1 = 1;
						MW2 = 1;
            MW3 = 0;
						CTw++;
            CTR4 = 1;
			TIMC_Flag4=0;
          }
       break;

       case 1:		 // AB
         if(TIMC_Flag4)
          {	
            MW0 = 1;		   //0xf3 
            MW1 = 1;
           	MW2 = 1;
            MW3 = 0;
						CTw++;
            CTR4 = 2;
			TIMC_Flag4=0;
          }
       break;

       case 2:	   //B
         if(TIMC_Flag4)
          {
           
          	MW0 = 1;
            MW1 = 1;		  //0xf2 
            MW2 = 0;
            MW3 = 0;
           CTw++;
            CTR4 = 3;
			TIMC_Flag4=0;
          }
       break;


       case 3:		//BC
         if(TIMC_Flag4)
          {	
            MW0 = 1;
            MW1 = 1;		    //0xf6
            MW2 = 0;
            MW3 = 1;
						CTw++;
            CTR4 = 4;
			TIMC_Flag4=0;
          }
       break;
     case 4:		 //C
         if(TIMC_Flag4)
          {	
            MW0 = 1;
            MW1 = 0;		    //0xf4
            MW2 = 0;
            MW3 = 1;
						CTw++;
            CTR4 = 5;
			TIMC_Flag4=0;
           }
       break;
	case 5:			  //CD
         if(TIMC_Flag4)
          {	
            MW0 = 1;
            MW1 = 0;		    //0xfc
            MW2 = 1;
            MW3 = 1;
						CTw++;
            CTR4 = 6;
			TIMC_Flag4=0;
          }
       break;
	case 6:			  //D
         if(TIMC_Flag4)
          {	
            MW0 = 0;
            MW1 = 0;		    //0xf8
            MW2 = 1;
            MW3 = 1;
						CTw++;
            CTR4 = 7;
			TIMC_Flag4=0;
          }
       break;
	case 7:			//DA
         if(TIMC_Flag4)
          {	
            MW0 = 0;
            MW1 = 1;		    //0xf9
            MW2 = 1;
            MW3 = 1;
						CTw++;
            CTR4 = 0;
			TIMC_Flag4=0;
          }
       break;
			}
	}
	
		 	if(dir==7)
	{
		switch(CTR4)
    {
       case 0:
          if(TIMC_Flag4)   // A
          {				    
            MW0 = 0;		    //0xf1             0111 0011 1011 1001 1101 1100 1110 0110
            MW1 = 1;
						MW2 = 1;
            MW3 = 1;
						CTw--;
            CTR4 = 1;
			TIMC_Flag4=0;
          }
       break;

       case 1:		 // AB
         if(TIMC_Flag4)
          {	
            MW0 = 0;		   //0xf3 
            MW1 = 0;
           	MW2 = 1;
            MW3 = 1;
						CTw--;
            CTR4 = 2;
			TIMC_Flag4=0;
          }
       break;

       case 2:	   //B
         if(TIMC_Flag4)
          {
           
          	MW0 = 1;
            MW1 = 0;		  //0xf2 
            MW2 = 1;
            MW3 = 1;
           CTw--;
            CTR4 = 3;
			TIMC_Flag4=0;
          }
       break;


       case 3:		//BC
         if(TIMC_Flag4)
          {	
            MW0 = 1;
            MW1 = 0;		    //0xf6
            MW2 = 0;
            MW3 = 1;
						CTw--;
            CTR4 = 4;
			TIMC_Flag4=0;
          }
       break;
     case 4:		 //C
         if(TIMC_Flag4)
          {	
            MW0 = 1;
            MW1 = 1;		    //0xf4
            MW2 = 0;
            MW3 = 1;
						CTw--;
            CTR4 = 5;
			TIMC_Flag4=0;
           }
       break;
	case 5:			  //CD
         if(TIMC_Flag4)
          {	
            MW0 = 1;
            MW1 = 1;		    //0xfc
            MW2 = 0;
            MW3 = 0;
						CTw--;
            CTR4 = 6;
			TIMC_Flag4=0;
          }
       break;
	case 6:			  //D
         if(TIMC_Flag4)
          {	
            MW0 = 1;
            MW1 = 1;		    //0xf8
            MW2 = 1;
            MW3 = 0;
						CTw--;
            CTR4 = 7;
			TIMC_Flag4=0;
          }
       break;
	case 7:			//DA
         if(TIMC_Flag4)
          {	
            MW0 = 0;
            MW1 = 1;		    //0xf9
            MW2 = 1;
            MW3 = 0;
						CTw--;
            CTR4 = 0;
			TIMC_Flag4=0;
          }
       break;
			}
	}
	
}
