#include "sys_config.h"
#include "stm32f10x.h"
#include "math.h"
extern void IWDG_Feed(void);
extern u8 px[32];
void FIRECON(void);
const int num595=11;
// #define SHCP595 PCout(15)
// #define STCP595 PCout(14)
// #define DS PCout(13)
unsigned char fire_cahce[num595];
int fir_flag_sw;
int fin_flag;
