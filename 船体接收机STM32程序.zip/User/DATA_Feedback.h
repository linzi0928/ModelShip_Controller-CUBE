#include "sys_config.h"
#include "stm32f10x.h"
#include "Usart.h"
u32 temper=0,c=0;
u16 adcx,adcx2;
float temp,temp2; 
extern void IWDG_Feed(void);
void Soft_WDG(void);
extern u8 px[30];
int WDN[50]={0},WDNS=0,WDNSS=0,WDNSR=0;
extern u16 Get_Adc_Average(u8 ch,u8 times);
extern u8 TxBuf[4];
extern short DS18B20_Get_Temp(void);
extern int Rssi1278;
