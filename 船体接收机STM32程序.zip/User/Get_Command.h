#include "sys_config.h"
#include "stm32f10x.h"
#include "wdg.h"
#define BUFFER_SIZE     20                          // Define the payload size here
static uint16_t BufferSize = BUFFER_SIZE;			// RF buffer size
static uint8_t  Buffer[BUFFER_SIZE];				// RF buffer
tRadioDriver *Radio = NULL;
#define SX1278_RX
u8 px[32];
extern u16 led0pwmval,servo,fso,a,tt,servox,servoy,tservo;
void Command_Process(void);
u32 dy_min,dy_mid,dy_max,servo_dir_min,servo_dir_mid,servo_dir_max;
extern void Setting_refresh(void);
extern u8 ch_dy,ch_dir;
void PWM_Out(u8 ch,uint16_t Compare);
u32 servo_val[36];
u32 servo_calc(u32 ad_val,u32 s_min,u32 s_max,u32 s_mid);
u8 chx,chy,errflag;
extern void One_Step(int dir);
extern void Motor_Init(void);
u8 TxBuf[4]={0x00,0xdd,0xac,0};
#define Ship_ID 27
extern const int num595;
extern unsigned char fire_cahce[];
extern int fir_flag_sw;
extern int fin_flag;
extern void drv595(unsigned char val595[]);
extern void FIRECON(void);
int refresh_flag;
extern short DS18B20_Get_Temp(void);
extern double SX1276LoRaGetPacketRssi( void );
int Rssi1278;
int debug_mode_check(void);
extern u8 freq_flag;
extern u8 Setting_Buffer[];
