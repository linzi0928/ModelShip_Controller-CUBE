 1. 连接状态更新不及时
 2. notify通知不到
 3. 维持长连接
 4. 给service去掉
 5. 串行化队列抽象出来，可参考rxjava
 6. 通过注入来confirm所在线程
 7. 支持新android api
 8. hook系统的gatt
 9. 连接断掉时自动clearRequest
 10. 搜索增强
 11. 不要用广播，都用事件总线