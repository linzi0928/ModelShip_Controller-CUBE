package com.inuker.bluetooth.library.connect.response;

/**
 * Created by fuhao on 2017/8/24.
 */

public interface BleMtuResponse extends BleTResponse<Integer>{
}
