package com.kongqw.rockerlibrary;

/**
 * Created by kqw on 2016/9/1.
 * Logger
 */
public class Logger {

    public static void i(String tag, String msg) {
        // Log.i(tag, msg);
    }
}
