package com.inuker.bluetooth;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.NumberPicker;
import android.widget.Toast;

import com.kyleduo.switchbutton.SwitchButton;

import static com.inuker.bluetooth.MainInterface.Command_buffer;
import static com.inuker.bluetooth.MainInterface.uint2byte;

public class Setting_Menu extends Activity {
    private Button mBtn_Return_Main;
    //private Button mBtn_Write_Servo;
    private Button mBtn_CH11R;
    private Button mBtn_CH10R;
    private Button mBtn_CH00R;
    private Button mBtn_CH01R;
    private Button mBtn_CH02R;
    private Button mBtn_CH03R;
    private Button mBtn_CH04R;
    private Button mBtn_CH05R;
    private Button mBtn_CH06R;
    private Button mBtn_CH07R;
    private Button mBtn_CH08R;
    private Button mBtn_CH09R;
    private SwitchButton RF_CH_SW;
    private SwitchButton Step_CH1_Prog_SW;
    private SwitchButton Step_CH2_Prog_SW;
    private SwitchButton Step_CH1_Dir_SW;
    private SwitchButton Step_CH2_Dir_SW;
    private int Servo_max=1380;
    private int Servo_mid=1350;
    private int Servo_min=1330;
    private int Servo_CH=1;
    private boolean CH169=true;
    private boolean rocker_flag=false;
    public boolean step_flag=false;
    private boolean S01_dir_st=false;
    private boolean S02_dir_st=false;
    private boolean S01_prog_st=false;
    private boolean S02_prog_st=false;
    NumberPicker MaxPicker;
    NumberPicker MidPicker;
    NumberPicker MinPicker;
    NumberPicker CHPicker;
    NumberPicker Step_Speed;
    NumberPicker Step_CH1;
    NumberPicker Step_CH2;
    NumberPicker Step_Prog;
    NumberPicker RF_CHPicker;
    NumberPicker Step_Angle_CH1;
    NumberPicker Step_Angle_CH2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting_menu_activity);
        number_picker_init();
        if(Command_buffer[11]==0&&Command_buffer[12]==0)
        {
            rocker_flag=true;
        }
        RF_CH_SW= findViewById(R.id.ch_169_433);
        RF_CH_SW.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    CH169=true;
                    Command_buffer[15]&=uint2byte(0x7f);
                    RF_CHPicker.setMaxValue(190);
                    RF_CHPicker.setMinValue(150);
                    RF_CHPicker.setValue(169);
                }
                else
                {
                    CH169=false;
                    Command_buffer[15]|=uint2byte(0x80);
                    RF_CHPicker.setMaxValue(450);
                    RF_CHPicker.setMinValue(410);
                    RF_CHPicker.setValue(433);
                }
            }
        });
        Step_CH1_Prog_SW=findViewById(R.id.step_prog_01mode);
        Step_CH1_Prog_SW.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    S01_prog_st=false;
                }
                else
                {
                    S01_prog_st=true;
                }
            }
        });
        Step_CH2_Prog_SW=findViewById(R.id.step_prog_02mode);
        Step_CH2_Prog_SW.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    S02_prog_st=false;
                }
                else
                {
                    S02_prog_st=true;
                }
            }
        });
        Step_CH1_Dir_SW=findViewById(R.id.step_prog_01dir);
        Step_CH1_Dir_SW.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    S01_dir_st=false;
                }
                else
                {
                    S01_dir_st=true;
                }
            }
        });
        Step_CH2_Dir_SW=findViewById(R.id.step_prog_02dir);
        Step_CH2_Dir_SW.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    S02_dir_st=false;
                }
                else
                {
                    S02_dir_st=true;
                }
            }
        });
        mBtn_Return_Main=findViewById(R.id.return_Main);
        mBtn_Return_Main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(rocker_flag)
                {
                 Command_buffer[11]=0;
                Command_buffer[12]=0;
                }
                else
                {
                    Command_buffer[11]=0x03;
                    Command_buffer[12]=uint2byte(0xe7);
                }
                Intent intent=new Intent(Setting_Menu.this,MainInterface.class);
                startActivity(intent);
            }
        });
//        mBtn_Write_Servo=findViewById(R.id.writeservo);
//        mBtn_Write_Servo.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });
        mBtn_CH11R=findViewById(R.id.CH11R);
        mBtn_CH11R.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonUtils.toast("电调通道已反转");
                Command_buffer[18]=0x0c;
            }
        });
        mBtn_CH10R=findViewById(R.id.CH10R);
        mBtn_CH10R.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonUtils.toast("主舵通道已反转");
                Command_buffer[18]=0x0b;
            }
        });
        mBtn_CH09R=findViewById(R.id.CH09R);
        mBtn_CH09R.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonUtils.toast("9通道已反转");
                Command_buffer[18]=0x0a;
            }
        });
        mBtn_CH08R=findViewById(R.id.CH08R);
        mBtn_CH08R.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonUtils.toast("8通道已反转");
                Command_buffer[18]=0x09;
            }
        });
        mBtn_CH07R=findViewById(R.id.CH07R);
        mBtn_CH07R.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonUtils.toast("7通道已反转");
                Command_buffer[18]=0x08;
            }
        });
        mBtn_CH06R=findViewById(R.id.CH06R);
        mBtn_CH06R.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonUtils.toast("6通道已反转");
                Command_buffer[18]=0x07;
            }
        });
        mBtn_CH05R=findViewById(R.id.CH05R);
        mBtn_CH05R.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonUtils.toast("5通道已反转");
                Command_buffer[18]=0x06;
            }
        });
        mBtn_CH04R=findViewById(R.id.CH04R);
        mBtn_CH04R.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonUtils.toast("4通道已反转");
                Command_buffer[18]=0x05;
            }
        });
        mBtn_CH03R=findViewById(R.id.CH03R);
        mBtn_CH03R.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonUtils.toast("3通道已反转");
                Command_buffer[18]=0x04;
            }
        });
        mBtn_CH02R=findViewById(R.id.CH02R);
        mBtn_CH02R.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonUtils.toast("2通道已反转");
                Command_buffer[18]=0x03;
            }
        });
        mBtn_CH01R=findViewById(R.id.CH01R);
        mBtn_CH01R.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonUtils.toast("1道已反转");
                Command_buffer[18]=0x02;
            }
        });
        mBtn_CH00R=findViewById(R.id.CH00R);
        mBtn_CH00R.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonUtils.toast("0通道已反转");
                Command_buffer[18]=0x01;
            }
        });
    }
    private void number_picker_init()
    {
        MaxPicker=findViewById(R.id.max_picker);
        MidPicker=findViewById(R.id.mid_picker);
        MinPicker=findViewById(R.id.min_picker);
        CHPicker =findViewById(R.id.servoselect);
        Step_Speed=findViewById(R.id.step_speed_picker);
        Step_CH1=findViewById(R.id.step_ch1_picker);
        Step_CH2=findViewById(R.id.step_ch2_picker);
        Step_Prog=findViewById(R.id.step_speed_prog_picker);
        RF_CHPicker=findViewById(R.id.ch_picker);
        Step_Angle_CH1=findViewById(R.id.step_ch1_angle);
        Step_Angle_CH2=findViewById(R.id.step_ch2_angle);
        CHPicker.setMaxValue(11);
        CHPicker.setMinValue(0);
        CHPicker.setValue(0);
        MaxPicker.setMaxValue(1440);
        MaxPicker.setMinValue(1200);
        MaxPicker.setValue(1380);
        MidPicker.setMaxValue(1440);
        MidPicker.setMinValue(1200);
        MidPicker.setValue(1350);
        MinPicker.setMaxValue(1440);
        MinPicker.setMinValue(1200);
        MinPicker.setValue(1330);
        Step_Speed.setMaxValue(7);
        Step_Speed.setMinValue(1);
        Step_Speed.setValue(5);
        Step_Prog.setMaxValue(7);
        Step_Prog.setMinValue(1);
        Step_Prog.setValue(5);
        Step_CH1.setMaxValue(4);
        Step_CH1.setMinValue(0);
        Step_CH1.setValue(0);
        Step_CH2.setMaxValue(4);
        Step_CH2.setMinValue(0);
        Step_CH2.setValue(0);
        RF_CHPicker.setMinValue(150);
        RF_CHPicker.setMaxValue(190);
        RF_CHPicker.setValue(169);
        Step_Angle_CH1.setMinValue(1);
        Step_Angle_CH1.setMaxValue(7);
        Step_Angle_CH1.setValue(1);
        Step_Angle_CH2.setMinValue(1);
        Step_Angle_CH2.setMaxValue(7);
        Step_Angle_CH2.setValue(1);
        MaxPicker.setOnValueChangedListener(OnMaxPickerListener);
        MidPicker.setOnValueChangedListener(OnMidPickerListener);
        MinPicker.setOnValueChangedListener(OnMinPickerListener);
        CHPicker.setOnValueChangedListener(OnCHPickerListener);
        Step_Speed.setOnValueChangedListener(OnStepSpeedListener);
        Step_Prog.setOnValueChangedListener(OnStepProgListener);
        Step_CH1.setOnValueChangedListener(OnStepCH1Listener);
        Step_CH2.setOnValueChangedListener(OnStepCH2Listener);
        RF_CHPicker.setOnValueChangedListener(OnRFCHListener);
        Step_Angle_CH1.setOnValueChangedListener(OnStepAngleCH1Listener);
        Step_Angle_CH2.setOnValueChangedListener(OnStepAngleCH2Listener);
    }
    private NumberPicker.OnValueChangeListener OnMaxPickerListener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            Servo_max=newVal;
            Command_buffer[11]= uint2byte(Servo_max>>8);
            Command_buffer[12]= uint2byte(Servo_max&0x00ff);
            if(Servo_CH==10)
                Command_buffer[13]=uint2byte(0xd2);
            else if(Servo_CH==11)
                Command_buffer[13]=uint2byte(0xe2);
            else
                Command_buffer[13]=uint2byte(0x20|Servo_CH);
        }
    };
    private NumberPicker.OnValueChangeListener OnMidPickerListener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            Servo_mid=newVal;
            Command_buffer[11]= uint2byte(Servo_mid>>8);
            Command_buffer[12]= uint2byte(Servo_mid&0x00ff);
            if(Servo_CH==10)
                Command_buffer[13]=uint2byte(0xd1);
            else if(Servo_CH==11)
                Command_buffer[13]=uint2byte(0xe1);
            else
                Command_buffer[13]=uint2byte(0x10|Servo_CH);
        }
    };
    private NumberPicker.OnValueChangeListener OnMinPickerListener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            Servo_min=newVal;
            Command_buffer[11]= uint2byte(Servo_min>>8);
            Command_buffer[12]= uint2byte(Servo_min&0x00ff);
            if(Servo_CH==10)
                Command_buffer[13]=uint2byte(0xd0);
            else if(Servo_CH==11)
                Command_buffer[13]=uint2byte(0xe0);
            else
                Command_buffer[13]=uint2byte(Servo_CH);
        }
    };
    private NumberPicker.OnValueChangeListener OnCHPickerListener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            Servo_CH=newVal;
            Command_buffer[11]=0;
            Command_buffer[12]=0;
            if(Servo_CH==10)
                Command_buffer[13]=uint2byte(0xd0);
            else if(Servo_CH==11)
                Command_buffer[13]=uint2byte(0xe0);
            else
                Command_buffer[13]=uint2byte(Servo_CH);
            Servo_min=0;
            Servo_mid=0;
            Servo_max=0;
        }
    };
    private NumberPicker.OnValueChangeListener OnStepSpeedListener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            Command_buffer[14]&=0x0f;
            Command_buffer[14]|=(newVal<<4);
        }
    };
    private NumberPicker.OnValueChangeListener OnStepProgListener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            Command_buffer[14]&=0xf0;
            Command_buffer[14]|=newVal;
        }
    };
    private NumberPicker.OnValueChangeListener OnStepCH1Listener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            if(S01_prog_st) {
                Command_buffer[17] = 0x06;
            }
            else
                Command_buffer[17]=0x04;
        }
    };
    private NumberPicker.OnValueChangeListener OnStepCH2Listener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            if(S01_prog_st) {
                Command_buffer[17] = 0x07;
            }
            else
                Command_buffer[17]=0x04;
        }
    };
    private NumberPicker.OnValueChangeListener OnRFCHListener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            //150-190Mhz
            //410-450Mhz
            if(CH169)
            {
                Command_buffer[15]=uint2byte(newVal-149);
                Command_buffer[15]&=0x7f;
            }
            else
            {
                Command_buffer[15]=uint2byte(newVal-409);
                Command_buffer[15]|=0x80;
            }
        }
    };
    private NumberPicker.OnValueChangeListener OnStepAngleCH1Listener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {

        }
    };
    private NumberPicker.OnValueChangeListener OnStepAngleCH2Listener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {

        }
    };
}
