package com.inuker.bluetooth;

import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.inuker.bluetooth.library.connect.response.BleWriteResponse;
import com.jaygoo.widget.OnRangeChangedListener;
import com.jaygoo.widget.RangeSeekBar;
import com.jaygoo.widget.VerticalRangeSeekBar;
import com.inuker.bluetooth.library.connect.listener.BleConnectStatusListener;
import com.inuker.bluetooth.library.connect.options.BleConnectOptions;
import com.inuker.bluetooth.library.connect.response.BleConnectResponse;
import com.inuker.bluetooth.library.model.BleGattProfile;
import com.inuker.bluetooth.library.search.SearchResult;
import com.inuker.bluetooth.library.utils.BluetoothLog;
import com.inuker.bluetooth.library.utils.BluetoothUtils;
import com.kongqw.rockerlibrary.view.RockerView;
import com.kyleduo.switchbutton.SwitchButton;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;
import static com.inuker.bluetooth.library.Constants.*;
import static com.jaygoo.widget.RangeSeekBar.TRICK_MARK_MODE_NUMBER;
import static com.jaygoo.widget.RangeSeekBar.TRICK_MARK_MODE_OTHER;
import static java.security.CryptoPrimitive.MAC;

import android.media.MediaPlayer;
import android.net.Uri;
import android.view.Window;
import android.view.WindowManager;
import android.widget.VideoView;

import java.util.UUID;

/**
 * 船模主控制界面
 * GIE Studio
 * 2020/08/12
 */
public class MainInterface extends Activity {
   // public static MainInterface inst = null;
    private TextView mTvTitle;
    private ProgressBar mPbar;

    private ListView mListView;
    private DeviceDetailAdapter mAdapter;

    private SearchResult mResult;
    private VerticalRangeSeekBar Throttle_BAR;
    private VerticalRangeSeekBar Gear_BAR;
    private RangeSeekBar SafeBAR;
    private BluetoothDevice mDevice;
    private String mMac;
    private UUID mService=UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb");
    private UUID mCharacter_Recv=UUID.fromString("0000fff6-0000-1000-8000-00805f9b34fb");
    private UUID mCharacter_Send=UUID.fromString("0000fff1-0000-1000-8000-00805f9b34fb");
    public static byte[] Command_buffer={20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,30};
    private int Throttle_Val=100;
    private int Throttle_Val_raw=0;
    private int Gear_Val=50;
    private  int Rudder_Val=50;
    private int ZeroCh_Val=50;
    private  int Rocker_X_ex=50;
    private int Rocker_Y_ex=50;
    private static int Fire_CH=72;
    private static int Ser_CH=12;
    private static int fire_fuse=0;
    private  static  int fire_mode=0;
    private static int fire_time=20;
    private static int fire_count=0;
    private static int rev_count=0;
    public static int return_flag=0;
    private int pack_count=0;
    private boolean mConnected;
    private TextView fire_TXT;
    private TextView Safe_text;
    private TextView SW073_TX;
    private TextView SW072_TX;
    private TextView SW001_TX;
    private Button mBtn_Menu;
    private Button mBtn_Return;
    private Button mBtn_Fire;
    private SwitchButton Fire_Mode_SW;
    private SwitchButton CH73SW;
    private SwitchButton CH72SW;
    private SwitchButton CH01SW;
    private SwitchButton step_01;
    private SwitchButton step_02;
    private SwitchButton step_03;
    private SwitchButton step_04;
    private SwitchButton step_01sw;
    private SwitchButton step_02sw;
    private SwitchButton step_03sw;
    private SwitchButton step_04sw;
    private SwitchButton rocker_sw;
    private boolean step1_st=true;
    private boolean step2_st=true;
    private boolean step3_st=true;
    private boolean step4_st=true;
    private boolean step1_dir=false;
    private boolean step2_dir=false;
    private boolean step3_dir=false;
    private boolean step4_dir=false;
    private boolean step_flag=true;
    NumberPicker fire10Picker;
    NumberPicker fire1Picker;
    NumberPicker ser10Picker;
    NumberPicker ser1Picker;
    NumberPicker stepPicker;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.device_detail_activity);
        Command_buffer[19]=uint2byte(0xfd);
        Command_buffer[0]=uint2byte(0xdf);
        Command_buffer[7]=0x00;
        Command_buffer[10]=uint2byte(0xaa);
        Command_buffer[17]=0x01;
        Intent intent = getIntent();
        String mac = intent.getStringExtra("mac");
        mResult = intent.getParcelableExtra("device");
        mDevice = BluetoothUtils.getRemoteDevice(mac);
        range_bar_init();
        num_picker_init();
      //  mTvTitle = (TextView) findViewById(R.id.title);
//        mTvTitle.setText(mDevice.getAddress());

        Fire_Mode_SW =  findViewById(R.id.f_mode_sw);
        CH73SW =  findViewById(R.id.sw01);
        CH72SW = findViewById(R.id.sw02);
        CH01SW = findViewById(R.id.sw03);
        step_01=findViewById(R.id.step01);
        step_02=findViewById(R.id.step02);
        step_03=findViewById(R.id.step03);
        step_04=findViewById(R.id.step04);
        step_01sw=findViewById(R.id.step01sw);
        step_01sw.setChecked(true);
        step_02sw=findViewById(R.id.step02sw);
        step_02sw.setChecked(true);
        step_03sw=findViewById(R.id.step03sw);
        step_03sw.setChecked(true);
        step_04sw=findViewById(R.id.step04sw);
        step_04sw.setChecked(true);
        SW073_TX=findViewById(R.id.sw_1);
        SW072_TX=findViewById(R.id.sw_2);
        SW001_TX=findViewById(R.id.sw_3);
        rocker_sw=findViewById(R.id.rockerswitch);
        rocker_sw.setChecked(true);
        mBtn_Fire=(Button)findViewById(R.id.fire_btn);
        mBtn_Menu=(Button)findViewById(R.id.main_menu);
        mBtn_Return=(Button)findViewById(R.id.return_list);
        mBtn_Return.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainInterface.this,MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK| FLAG_ACTIVITY_NEW_TASK);
                return_flag=1;
                startActivity(intent);
            }
        });
        mBtn_Menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainInterface.this,Setting_Menu.class);
                startActivity(intent);
            }
        });
        mBtn_Fire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(fire_fuse==100)
                {
                    if(fire_mode==0) {
                        Command_buffer[7]=uint2byte(fire_time);
                        CommonUtils.toast("火控模式发射成功");
                    }
                    else
                    {
                        Command_buffer[7]=uint2byte(0xf0);
                        CommonUtils.toast("开关模式电平已经反转");
                    }
                }
                else
                {
                    CommonUtils.toast("操作失败，保险未就位");
                }
            }
        });

        Fire_Mode_SW.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    fire_mode=0;
                    CommonUtils.toast("切换至火控发射模式");
                }
                else
                {
                    fire_mode=1;
                    CommonUtils.toast("切换至开关模式");
                }
            }
        });
        CH73SW.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    Command_buffer[7]=uint2byte(0xfe);
                    Command_buffer[4]=uint2byte(73);
                    SW073_TX.setTextColor(Color.parseColor("#FFFFFF"));
                }
                else
                {
                    Command_buffer[7]=uint2byte(0xfd);
                    Command_buffer[4]=uint2byte(73);
                    SW073_TX.setTextColor(Color.parseColor("#13b791"));
                }
            }
        });
        CH72SW.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    Command_buffer[7]=uint2byte(0xfe);
                    Command_buffer[4]=uint2byte(72);
                    SW072_TX.setTextColor(Color.parseColor("#FFFFFF"));
                }
                else
                {
                    Command_buffer[7]=uint2byte(0xfd);
                    Command_buffer[4]=uint2byte(72);
                    SW072_TX.setTextColor(Color.parseColor("#13b791"));
                }
            }
        });
        CH01SW.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    Command_buffer[7]=uint2byte(0xfe);
                    Command_buffer[4]=uint2byte(1);
                    SW001_TX.setTextColor(Color.parseColor("#FFFFFF"));
                }
                else
                {
                    Command_buffer[7]=uint2byte(0xfd);
                    Command_buffer[4]=uint2byte(1);
                    SW001_TX.setTextColor(Color.parseColor("#13b791"));
                }
            }
        });
        step_01.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    step1_dir=false;
                    if(!step1_st) {
                        Command_buffer[10] |= 0xc0;
                    }
                    else
                    {
                        Command_buffer[10] |= 0xc0;
                        Command_buffer[10] &= 0xbf;
                    }
                }
                else
                {
                    step1_dir=true;
                    if(!step1_st) {
                        Command_buffer[10] |= 0xc0;
                    }
                    else
                    {
                        Command_buffer[10] |= 0xc0;
                        Command_buffer[10] &= 0x7f;
                    }
                }
            }
        });
        step_02.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    step2_dir=false;
                    if(!step2_st) {
                        Command_buffer[10] |= 0x30;
                    }
                    else
                    {
                        Command_buffer[10] |= 0x30;
                        Command_buffer[10] &= 0xef;
                    }
                }
                else
                {
                    step2_dir=true;
                    if(!step2_st) {
                        Command_buffer[10] |= 0x30;
                    }
                    else
                    {
                        Command_buffer[10] |= 0x30;
                        Command_buffer[10] &= 0xdf;
                    }
                }
            }
        });
        step_03.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    step3_dir=false;
                    if(!step3_st) {
                        Command_buffer[10] |= 0x0c;
                    }
                    else
                    {
                        Command_buffer[10] |= 0x0c;
                        Command_buffer[10] &= 0xfb;
                    }
                }
                else
                {
                    step3_dir=true;
                    if(!step3_st) {
                        Command_buffer[10] |= 0x0c;
                    }
                    else
                    {
                        Command_buffer[10] |= 0x0c;
                        Command_buffer[10] &= 0xf7;
                    }
                }
            }
        });
        step_04.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    step4_dir=false;
                    if(!step4_st) {
                        Command_buffer[10] |= 0x03;
                    }
                    else
                    {
                        Command_buffer[10] |= 0x03;
                        Command_buffer[10] &= 0xfe;
                    }
                }
                else
                {
                    step4_dir=true;
                    if(!step4_st) {
                        Command_buffer[10] |= 0x03;
                    }
                    else
                    {
                        Command_buffer[10] |= 0x03;
                        Command_buffer[10] &= 0xfd;
                    }
                }
            }
        });
        step_01sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    step1_st=false;
                    Command_buffer[10] |= 0xc0;
                }
                else
                {
                    step1_st=true;
                    if(step1_dir)
                        Command_buffer[10] &= 0x7f;
                    else
                        Command_buffer[10]&= 0xbf;
                }
            }
        });
        step_02sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    step2_st=false;
                    Command_buffer[10] |= 0x30;
                }
                else
                {
                    step2_st=true;
                    if(step2_dir)
                        Command_buffer[10] &= 0xdf;
                    else
                        Command_buffer[10]&= 0xef;
                }
            }
        });
        step_03sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    step3_st=false;
                    Command_buffer[10] |= 0x0c;
                }
                else
                {
                    step3_st=true;
                    if(step3_dir)
                        Command_buffer[10] &= 0xf7;
                    else
                        Command_buffer[10]&= 0xfb;
                }
            }
        });
        step_04sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    step4_st=false;
                    Command_buffer[10] |= 0x03;
                }
                else
                {
                    step4_st=true;
                    if(step4_dir)
                        Command_buffer[10] &= 0xfd;
                    else
                        Command_buffer[10]&= 0xfe;
                }
            }
        });
        rocker_sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked)
                {
                    step_flag=false;
                    Command_buffer[11]=0x03;
                    Command_buffer[12]=uint2byte(0xE7);
                }
                else
                {
                    step_flag=true;
                    Command_buffer[11]=0;
                    Command_buffer[12]=0;
                }
            }
        });
        mPbar = (ProgressBar) findViewById(R.id.pbar);
        fire_TXT =  findViewById(R.id.fire_text);
        Safe_text= findViewById(R.id.safe_text);
        //mListView = (ListView) findViewById(R.id.listview);
        mAdapter = new DeviceDetailAdapter(this, mDevice);
       // mListView.setAdapter(mAdapter);
        RockerView rockerView = (RockerView) findViewById(R.id.rockerView);
        rockerView.setCallBackMode(RockerView.CallBackMode.CALL_BACK_MODE_STATE_CHANGE);
        RockerView rockerView_ex = (RockerView) findViewById(R.id.rockerView_F);
        rockerView_ex.setCallBackMode(RockerView.CallBackMode.CALL_BACK_MODE_STATE_CHANGE);

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Command_buffer[1]=uint2byte(Rudder_Val);
                Command_buffer[2]=uint2byte(Throttle_Val);
                Command_buffer[3]=uint2byte(0xaf);
                Command_buffer[9]=uint2byte(ZeroCh_Val);
                Command_buffer[5]=uint2byte(Rocker_X_ex);
                Command_buffer[6]=uint2byte(Rocker_Y_ex);
                if(!(Command_buffer[7]!=0x00&&(Command_buffer[4]==1||Command_buffer[4]==73||Command_buffer[4]==72))) {
                    Command_buffer[4] = uint2byte(Fire_CH);
                }
                Command_buffer[8]=uint2byte(Ser_CH);
                if(Command_buffer[7]!=0x00) {
                    fire_count++;
                }
                if(fire_count>=5) {
                    fire_count = 0;
                    Command_buffer[7]=0;
                }
                if(Command_buffer[18]!=0x00)
                {
                    rev_count++;
                }
                if(rev_count>=5)
                {
                    rev_count=0;
                    Command_buffer[18]=0;
                }
                pack_count++;
                if(pack_count>140)
                {
                    Command_buffer[3]=uint2byte(0xfa);
                    pack_count++;
                    if(pack_count>143) {
                        pack_count = 0;
                        Command_buffer[3]=uint2byte(0xaf);
                    }
                }
                ClientManager.getClient().write(mDevice.getAddress(), mService, mCharacter_Send, Command_buffer, new BleWriteResponse() {
                    @Override
                    public void onResponse(int code) {
//                        if (code == REQUEST_SUCCESS) {
//
//                        }
//                        else
//                        {
//                            CommonUtils.toast("failed");
//                        }
                    }
                });
                handler.postDelayed(this, 50);
            }
        }, 70);
        rockerView.setOnAngleChangeListener(new RockerView.OnAngleChangeListener() {
            @Override
            public void onStart() {
             //   mLogRight.setText(null);
            }

            @Override
            public void angle(double angle) {
                //CommonUtils.toast("摇动角度 : " + angle);
                Rudder_Val=((int)(angle)/10000)/20;
                ZeroCh_Val=((int)(angle)%10000)/20;
            }

            @Override
            public void onFinish() {
                Rudder_Val=50;
                ZeroCh_Val=50;
            }
        });
        rockerView_ex.setOnAngleChangeListener(new RockerView.OnAngleChangeListener() {
            @Override
            public void onStart() {
                //   mLogRight.setText(null);
            }

            @Override
            public void angle(double angle) {
                //CommonUtils.toast("摇动角度 : " + angle);
                    Rocker_X_ex = ((int) (angle) / 10000) / 20;
                    Rocker_Y_ex = ((int) (angle) % 10000) / 20;

            }

            @Override
            public void onFinish() {
                Rocker_X_ex=50;
                Rocker_Y_ex=50;
            }
        });
//        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                if (!mConnected) {
//                    return;
//                }
//                DetailItem item = (DetailItem) mAdapter.getItem(position);
//                if (item.type == DetailItem.TYPE_CHARACTER) {
//                    BluetoothLog.v(String.format("click service = %s, character = %s", item.service, item.uuid));
//                    startCharacterActivity(item.service, item.uuid);
//                    //数据发送uuid:0000fff6-0000-1000-8000-00805f9b34fb，数据接收uuid:0000fff1-0000-1000-8000-00805f9b34fb，服务uuid：0000fff0-0000-1000-8000-00805f9b34fb
//                }
//            }
//        });

        ClientManager.getClient().registerConnectStatusListener(mDevice.getAddress(), mConnectStatusListener);

        connectDeviceIfNeeded();
    }
    public static byte uint2byte(int in_num)
    {
        byte res_num;
        if (in_num<127&&in_num>=0) {
            res_num = (byte)in_num;
            return res_num;
        }
        else
        {
            res_num= (byte)(in_num-256);
            return  res_num;
        }
    }
    private void range_bar_init()
    {
        CharSequence TickMarkArray[]={"    \n","—25%\n","—50%\n","—75%\n","   \n"};
        CharSequence GEARTickMarkArray[]={"R\n","N\n","D\n"};
        Throttle_BAR=findViewById(R.id.throttle);
        Gear_BAR=findViewById(R.id.gear);
        SafeBAR=findViewById(R.id.safe);
        Throttle_BAR.setSeekBarMode(VerticalRangeSeekBar.SEEKBAR_MODE_SINGLE);
        Throttle_BAR.setProgress(0f);
        Throttle_BAR.setRange(0f, 100f);
        Throttle_BAR.setGravity( RangeSeekBar.Gravity.CENTER);
        Throttle_BAR.getLeftSeekBar().setThumbHeight(80);
        Throttle_BAR.getLeftSeekBar().setThumbWidth(80);
        Throttle_BAR.setTickMarkTextArray(TickMarkArray);
        Throttle_BAR.setTickMarkMode(TRICK_MARK_MODE_NUMBER|TRICK_MARK_MODE_OTHER);
        Throttle_BAR.setTickMarkTextColor(Color.parseColor("#1bd1a5"));
        Throttle_BAR.setTickMarkTextMargin(-100);
      //  Throttle_BAR.getLeftSeekBar().setIndicatorBackgroundColor(Color.parseColor("#FFFF00"));
        Throttle_BAR.setProgressDrawableId(R.drawable.front_throttle);
        Throttle_BAR.setProgressDefaultDrawableId(R.drawable.bg_throttle);
        Throttle_BAR.setProgressHeight(40);
        Throttle_BAR.setIndicatorTextDecimalFormat("0");
        Throttle_BAR.invalidate();
        Gear_BAR.setSteps(2);
        Gear_BAR.setStepsWidth(10f);
        Gear_BAR.setStepsHeight(60f);
        Gear_BAR.setStepsAutoBonding(true);
        Gear_BAR.setProgress(50f);
        Gear_BAR.setProgressDefaultDrawableId(R.drawable.bg_throttle);
        Gear_BAR.setProgressDrawableId(R.drawable.bg_throttle);
        Gear_BAR.setProgressHeight(40);
        Gear_BAR.setGravity( RangeSeekBar.Gravity.CENTER);
        Gear_BAR.invalidate();
        SafeBAR.setProgressDefaultDrawableId(R.drawable.bg_throttle);
        SafeBAR.setProgressDrawableId(R.drawable.front_throttle);
        SafeBAR.setStepsWidth(10f);
        SafeBAR.setStepsHeight(60f);
        SafeBAR.setSteps(1);
        SafeBAR.setProgress(0f);
        SafeBAR.setProgressHeight(40);
        SafeBAR.setStepsAutoBonding(true);
        SafeBAR.setGravity( RangeSeekBar.Gravity.CENTER);
        SafeBAR.invalidate();
        Throttle_BAR.setOnRangeChangedListener(new OnRangeChangedListener() {
            @Override
            public void onRangeChanged(RangeSeekBar view, float leftValue, float rightValue, boolean isFromUser) {
                Throttle_Val_raw= (int) view.getLeftSeekBar().getProgress();
                if(Gear_Val==50) {
                    Throttle_Val = 100;//空档
                }
                else if(Gear_Val==100) {
                    Throttle_Val = 100 + Throttle_Val_raw;//前进档
                }
                else if(Gear_Val==0) {
                    Throttle_Val = 100 - Throttle_Val_raw;//倒退
                }

            }

            @Override
            public void onStartTrackingTouch(RangeSeekBar view,  boolean isLeft) {
                //start tracking touch
            }

            @Override
            public void onStopTrackingTouch(RangeSeekBar view,  boolean isLeft) {

            }
        });
        Gear_BAR.setOnRangeChangedListener(new OnRangeChangedListener() {
            @Override
            public void onRangeChanged(RangeSeekBar view, float leftValue, float rightValue, boolean isFromUser) {
                Gear_Val= (int)view.getLeftSeekBar().getProgress();//获取档位
                if(Gear_Val==50) {
                    Throttle_Val = 100;//空档
                }
                else if(Gear_Val==100) {
                    Throttle_Val = 100 + Throttle_Val_raw;//前进档
                }
                else if(Gear_Val==0) {
                    Throttle_Val = 100 - Throttle_Val_raw;//倒退
                }
            }

            @Override
            public void onStartTrackingTouch(RangeSeekBar view,  boolean isLeft) {
                //start tracking touch
            }

            @Override
            public void onStopTrackingTouch(RangeSeekBar view,  boolean isLeft) {

            }
        });
        SafeBAR.setOnRangeChangedListener(new OnRangeChangedListener() {
            @Override
            public void onRangeChanged(RangeSeekBar view, float leftValue, float rightValue, boolean isFromUser) {
                fire_fuse= (int)view.getLeftSeekBar().getProgress();//获取档位
                        if(fire_fuse==100) {
                            Safe_text.setText("ARMED");//ARMED
                            Safe_text.setTextColor(Color.parseColor("#FF0000"));
                            fire_TXT.setText("通道：CH"+ String.valueOf(Fire_CH)+"\n保险：\nARMED");
                        }
                        else {
                            Safe_text.setText("UNARMED");//UNARMED
                            Safe_text.setTextColor(Color.parseColor("#13b791"));
                            fire_TXT.setText("通道：CH"+ String.valueOf(Fire_CH)+"\n保险：\nUNARMED");
                        }
            }

            @Override
            public void onStartTrackingTouch(RangeSeekBar view,  boolean isLeft) {
                //start tracking touch
            }

            @Override
            public void onStopTrackingTouch(RangeSeekBar view,  boolean isLeft) {

            }
        });

    }
    private NumberPicker.OnValueChangeListener Onfire10Picker_Listener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            Fire_CH%=10;
            Fire_CH+=(newVal*10);
            if(fire_fuse==100) {
                fire_TXT.setText("通道：CH" + String.valueOf(Fire_CH) + "\n保险：\nARMED");
            }
            else{
                fire_TXT.setText("通道：CH" + String.valueOf(Fire_CH) + "\n保险：\nUNARMED");
            }
        }
    };
    private NumberPicker.OnValueChangeListener Onfire1Picker_Listener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            Fire_CH/=10;
            Fire_CH=Fire_CH*10+newVal;
            if(fire_fuse==100) {
                fire_TXT.setText("通道：CH" + String.valueOf(Fire_CH) + "\n保险：\nARMED");
            }
            else{
                fire_TXT.setText("通道：CH" + String.valueOf(Fire_CH) + "\n保险：\nUNARMED");
            }
        }
    };
    private NumberPicker.OnValueChangeListener Onser10Picker_Listener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            Ser_CH%=10;
            Ser_CH+=(newVal*10);

        }
    };
    private NumberPicker.OnValueChangeListener Onser1Picker_Listener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            Ser_CH/=10;
            Ser_CH=Ser_CH*10+newVal;

        }
    };
    private NumberPicker.OnValueChangeListener OnstepPicker_Listener = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            Command_buffer[17]=uint2byte(newVal);
        }
    };

    private void num_picker_init()
    {

        fire10Picker=findViewById(R.id.picker_fire10);
        fire1Picker=findViewById(R.id.picker_fire1);
        ser10Picker=findViewById(R.id.picker_ser10);
        ser1Picker=findViewById(R.id.picker_ser1);
        stepPicker=findViewById(R.id.step_group);
        fire10Picker.setMaxValue(9);
        fire10Picker.setMinValue(0);
        fire10Picker.setValue(7);
        fire1Picker.setMaxValue(9);
        fire1Picker.setMinValue(0);
        fire1Picker.setValue(2);
        ser10Picker.setMaxValue(9);
        ser10Picker.setMinValue(0);
        ser10Picker.setValue(1);
        ser1Picker.setMaxValue(9);
        ser1Picker.setMinValue(0);
        ser1Picker.setValue(2);
        stepPicker.setMaxValue(4);
        stepPicker.setMinValue(1);
        stepPicker.setValue(1);
        fire10Picker.setOnValueChangedListener(Onfire10Picker_Listener);
        fire1Picker.setOnValueChangedListener(Onfire1Picker_Listener);
        ser10Picker.setOnValueChangedListener(Onser10Picker_Listener);
        ser1Picker.setOnValueChangedListener(Onser1Picker_Listener);
        stepPicker.setOnValueChangedListener(OnstepPicker_Listener);
    }

    private final BleConnectStatusListener mConnectStatusListener = new BleConnectStatusListener() {
        @Override
        public void onConnectStatusChanged(String mac, int status) {

            mConnected = (status == STATUS_CONNECTED);
            connectDeviceIfNeeded();
        }
    };

    private void startCharacterActivity(UUID service, UUID character) {
        Intent intent = new Intent(this, CharacterActivity.class);
        intent.putExtra("mac", mDevice.getAddress());
        intent.putExtra("service", service);
        intent.putExtra("character", character);
        startActivity(intent);
    }

    private void connectDevice() {
        //mTvTitle.setText(String.format("%s%s", getString(R.string.connecting), mDevice.getAddress()));
        mPbar.setVisibility(View.VISIBLE);
       // mListView.setVisibility(View.GONE);

        BleConnectOptions options = new BleConnectOptions.Builder()
                .setConnectRetry(3)
                .setConnectTimeout(20000)
                .setServiceDiscoverRetry(3)
                .setServiceDiscoverTimeout(10000)
                .build();

        ClientManager.getClient().connect(mDevice.getAddress(), options, new BleConnectResponse() {
            @Override
            public void onResponse(int code, BleGattProfile profile) {
                BluetoothLog.v(String.format("profile:\n%s", profile));
              //  mTvTitle.setText(String.format("%s", mDevice.getAddress()));
                mPbar.setVisibility(View.GONE);
                //mListView.setVisibility(View.VISIBLE);

                if (code == REQUEST_SUCCESS) {
                    mAdapter.setGattProfile(profile);
                }
            }
        });
    }

    private void connectDeviceIfNeeded() {
        if (!mConnected) {
            connectDevice();
        }
    }

    @Override
    protected void onDestroy() {
        ClientManager.getClient().disconnect(mDevice.getAddress());
        ClientManager.getClient().unregisterConnectStatusListener(mDevice.getAddress(), mConnectStatusListener);
        super.onDestroy();
    }
}
